# Shodan API setup
- Visit [shodan.io](https://www.shodan.io/), create an account / login using your account. 
    >🚨 Official email id's are preferred for better user experience and API 
- Go to `Accounts` option on the top right corner, and select *Show API key*. 
    > ⚠️ Never expose that API key. 
- Store that inside `.env` file, 
    ```env
    SHODAN_API_KEY = (paste your code)
    ```
______
[Click Here to go back to the README file](../README.md)